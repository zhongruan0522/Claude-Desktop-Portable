#!/usr/bin/env python3
# 跨批次术语统一：按现有词典惯例修正新译文，改完重跑各批自检
import json, subprocess, sys

ROOT = '/workspace/Claude Desktop/work/batches'

def load(p):
    with open(p, encoding='utf-8') as f: return json.load(f)

def save(p, d):
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=1)

def patch(out_name, per_key=None, per_src=None):
    """per_key: {key: (old, new)}；per_src: [(英文含, (old, new))]"""
    op, sp = '%s/out-%s.json' % (ROOT, out_name), '%s/%s.json' % (ROOT, out_name)
    o, s = load(op), load(sp)
    n = 0
    for k, v in o.items():
        v0 = v
        if per_key and k in per_key:
            old, new = per_key[k]
            if old in v: v = v.replace(old, new)
        if per_src:
            for needle, (old, new) in per_src:
                if needle in s[k] and old in v:
                    v = v.replace(old, new)
        if v != v0: o[k] = v; n += 1
    save(op, o)
    r = subprocess.run(['python3', '/workspace/Claude Desktop/work/check-batch.py', sp, op],
                       capture_output=True, text=True)
    print('%s: 修改 %d 条; 自检: %s' % (out_name, n, r.stdout.strip().splitlines()[-1]))
    if r.returncode != 0:
        print(r.stdout); sys.exit(1)

# effort 档位统一为 低/中/高/极高/最高（现有词典惯例）
patch('batch-1', per_key={
    '11U+7vd072': ('xhigh {超高} max {最大}', 'xhigh {极高} max {最高}'),
    '1H3TrH47vO': ('xhigh {超高} max {最大}', 'xhigh {极高} max {最高}'),
})
patch('batch-2', per_key={
    'HnsRYgE9zp': ('xhigh {超高}', 'xhigh {极高}'),
})
# Quick Entry → 快速输入（现有惯例；batch-4 已是「快速输入（Quick Entry）」理想形式不动）
patch('batch-1', per_key={
    '3O+fRjXvM7': ('打开 Quick Entry 的快捷键', '打开快速输入的快捷键'),
})
patch('batch-6', per_key={
    'suTGWQrzC/': ('macOS 的 Quick Entry', 'macOS 的快速输入'),
})
# routine → 例行程序；scheduled task → 计划任务（现有词典主流惯例）
patch('batch-1', per_src=[('routine', ('例行任务', '例行程序')), ('scheduled task', ('定时任务', '计划任务'))])
patch('batch-4', per_src=[('routine', ('例行任务', '例行程序')), ('scheduled task', ('定时任务', '计划任务'))])
patch('batch-2', per_src=[('scheduled task', ('定时任务', '计划任务'))])
patch('batch-3', per_src=[('scheduled task', ('定时任务', '计划任务'))])
patch('batch-5', per_src=[('routine', ('例行任务', '例行程序')), ('routine', ('例程', '例行程序')), ('scheduled task', ('定时任务', '计划任务'))])
print('全部统一完成')
