#!/usr/bin/env python3
# 对 struct_fail 条目自动补齐缺失的 ICU 分支（分支内容取中文 other 分支），修复后 struct_ok 校验
import json, re

REPORT = json.load(open('/workspace/Claude Desktop/work/diff-report.json', encoding='utf-8'))
ICU_RE = re.compile(r'\{([A-Za-z_][A-Za-z0-9_.-]*),\s*(plural|selectordinal|select)\s*,')

def find_block_spans(s):
    """返回 [(变量, 类型, 匹配起止含外层花括号, 头部结束位)]，嵌套块只返回最外层。"""
    spans = []
    for m in ICU_RE.finditer(s):
        # 跳过嵌套在内层的块
        if any(a <= m.start() < b for _, _, a, b, _ in spans): continue
        depth = 0; j = m.start()
        while j < len(s):
            if s[j] == '{': depth += 1
            elif s[j] == '}':
                depth -= 1
                if depth == 0: break
            j += 1
        if depth == 0: spans.append((m.group(1), m.group(2), m.start(), j + 1, m.end()))
    return spans

def parse_branches(s):
    """解析块体（不含 '{var, type,' 头与外层 '}'），返回 [(分支名, 内容起, 内容止)]。"""
    out = []; k = 0
    s = re.sub(r'^\s*offset\s*:\s*\d+\s*', '', s, count=1)
    while k < len(s):
        bm = re.match(r'\s*(=[0-9]+|[A-Za-z][A-Za-z0-9]*)\s*\{', s[k:])
        if not bm: break
        name = bm.group(1)
        k += bm.end()
        d = 1; start = k
        while k < len(s) and d > 0:
            if s[k] == '{': d += 1
            elif s[k] == '}': d -= 1
            k += 1
        out.append((name, start, k - 1))  # 内容 span，不含花括号
    return out

def struct_ok(en, zh):
    a, b = str(en), str(zh)
    if a.count('{') != b.count('{') or a.count('}') != b.count('}'): return False
    if sorted(re.findall(r'<[^>]*>', a)) != sorted(re.findall(r'<[^>]*>', b)): return False
    return True

def try_fix(en, zh):
    """补齐中文译文里缺失的 ICU 分支；成功返回新译文，失败返回 None。"""
    en_spans = find_block_spans(en)
    zh_spans = find_block_spans(zh)
    if len(en_spans) != len(zh_spans): return None
    fix = zh
    for (ev, et, ea, eb, ehdr), (zv, zt, za, zb, zhdr) in zip(en_spans, zh_spans):
        if ev != zv or et != zt: return None
        ebrs = parse_branches(en[ehdr:eb - 1]); zbrs = parse_branches(fix[zhdr:zb - 1])
        znames = [n for n, _, _ in zbrs]
        if 'other' not in znames: return None
        zbody_off = zhdr
        other_content = next(fix[zbody_off + a:zbody_off + b] for n, a, b in zbrs if n == 'other')
        missing = [n for n, _, _ in ebrs if n not in znames]
        if not missing: continue
        # 在中文块的外层 '}' 之前插入缺失分支（分支内容取中文 other 分支）
        add = ''.join(' %s {%s}' % (n, other_content) for n in missing)
        fix = fix[:zb - 1] + add + fix[zb - 1:]
    return fix

fixed = {}; failed = {}
for k, pair in REPORT['frontend']['struct_fail'].items():
    new = try_fix(pair['en'], pair['zh'])
    if new is not None and struct_ok(pair['en'], new):
        fixed[k] = new
    else:
        failed[k] = pair

print('前端 struct_fail %d 条：自动补分支修复 %d，需重译 %d' % (len(REPORT['frontend']['struct_fail']), len(fixed), len(failed)))

shell_failed = dict(REPORT['desktop_shell']['struct_fail'])
sfixed = {}
for k, pair in shell_failed.items():
    new = try_fix(pair['en'], pair['zh'])
    if new is not None and struct_ok(pair['en'], new):
        sfixed[k] = new
    else:
        pass
print('桌面壳 struct_fail %d 条：自动修复 %d，需重译 %d' % (len(shell_failed), len(sfixed), len(shell_failed) - len(sfixed)))

json.dump({'fixed': fixed, 'need_retranslate': failed},
          open('/workspace/Claude Desktop/work/fix-plural.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
json.dump(sfixed, open('/workspace/Claude Desktop/work/shell-fix-plural.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
