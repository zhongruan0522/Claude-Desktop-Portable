#!/usr/bin/env python3
# 检查 Windows 词典中是否有可复用的译文（对新版 Linux en-US 通过 struct_ok）
import json, os, re

RES = '/workspace/cd-unpacked/usr/lib/claude-desktop/resources'
LANG = '/workspace/Claude Desktop/language/zh-CN'
REPORT = json.load(open('/workspace/Claude Desktop/work/diff-report.json', encoding='utf-8'))

def load(p):
    with open(p, encoding='utf-8') as f: return json.load(f)

def strip_icu(value):
    s = str(value); res = ''; i = 0
    while i < len(s):
        if s[i] == '{':
            depth = 0; j = i
            while j < len(s):
                if s[j] == '{': depth += 1
                elif s[j] == '}':
                    depth -= 1
                    if depth == 0: break
                j += 1
            if j < len(s) and re.match(r'^[A-Za-z_][A-Za-z0-9_.-]*,\s*(plural|selectordinal|select)\s*,', s[i+1:j]):
                res += '{__ICU__}'; i = j + 1; continue
        res += s[i]; i += 1
    return res

def _tokens(value):
    c = {}; st = strip_icu(value)
    for t in re.findall(r'<[^>]*>|\{[A-Za-z_][A-Za-z0-9_.-]*\}', st): c[t] = c.get(t, 0) + 1
    return c

def struct_ok(en, zh):
    a, b = str(en), str(zh)
    if a.count('{') != b.count('{') or a.count('}') != b.count('}'): return False
    if sorted(re.findall(r'<[^>]*>', a)) != sorted(re.findall(r'<[^>]*>', b)): return False
    if _tokens(a) != _tokens(b): return False
    return True

fe_en = load(os.path.join(RES, 'ion-dist/i18n/en-US.json'))
win = load(os.path.join(LANG, 'zh-CN.json'))
shell_en = load(os.path.join(RES, 'en-US.json'))
win_shell = load(os.path.join(LANG, 'desktop-shell/zh-CN.json'))

reuse_missing = {}
for k in REPORT['frontend']['missing']:
    w = win.get(k)
    if w and w != fe_en[k] and struct_ok(fe_en[k], w):
        reuse_missing[k] = w
reuse_fail = {}
for k in REPORT['frontend']['struct_fail']:
    w = win.get(k)
    if w and w != fe_en[k] and struct_ok(fe_en[k], w):
        reuse_fail[k] = w
reuse_eq = {}
for k in REPORT['frontend']['zh_eq_en']:
    w = win.get(k)
    if w and w != fe_en[k] and struct_ok(fe_en[k], w):
        reuse_eq[k] = w

shell_reuse = {}
for k in REPORT['desktop_shell']['struct_fail']:
    w = win_shell.get(k)
    if w and w != shell_en[k] and struct_ok(shell_en[k], w):
        shell_reuse[k] = w
for k in REPORT['desktop_shell']['zh_eq_en']:
    w = win_shell.get(k)
    if w and w != shell_en[k] and struct_ok(shell_en[k], w):
        shell_reuse[k] = w

out = {'frontend_reuse_missing': reuse_missing, 'frontend_reuse_fail': reuse_fail,
       'frontend_reuse_eq': reuse_eq, 'shell_reuse': shell_reuse}
print('可复用（Windows 译文对新 Linux 英文通过结构校验）:')
print('  missing 复用: %d/%d' % (len(reuse_missing), len(REPORT['frontend']['missing'])))
print('  struct_fail 复用: %d/%d' % (len(reuse_fail), len(REPORT['frontend']['struct_fail'])))
print('  zh==en 复用: %d/%d' % (len(reuse_eq), len(REPORT['frontend']['zh_eq_en'])))
print('  shell 复用: %d/%d' % (len(shell_reuse), len(REPORT['desktop_shell']['struct_fail']) + len(REPORT['desktop_shell']['zh_eq_en'])))
with open('/workspace/Claude Desktop/work/reuse.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
