#!/usr/bin/env python3
# 生成翻译批次文件：前端 missing + 需重译 struct_fail + 桌面壳待译
import json, os

REPORT = json.load(open('/workspace/Claude Desktop/work/diff-report.json', encoding='utf-8'))
FIX = json.load(open('/workspace/Claude Desktop/work/fix-plural.json', encoding='utf-8'))
FE_EN = json.load(open('/workspace/cd-unpacked/usr/lib/claude-desktop/resources/ion-dist/i18n/en-US.json', encoding='utf-8'))
SHELL_EN = json.load(open('/workspace/cd-unpacked/usr/lib/claude-desktop/resources/en-US.json', encoding='utf-8'))
SHELL_FIX = json.load(open('/workspace/Claude Desktop/work/shell-fix-plural.json', encoding='utf-8'))

frontend = {k: FE_EN[k] for k in REPORT['frontend']['missing']}
frontend.update({k: FE_EN[k] for k in FIX['need_retranslate']})
shell_need = [k for k in REPORT['desktop_shell']['struct_fail'] if k not in SHELL_FIX]
shell = {k: SHELL_EN[k] for k in shell_need}

os.makedirs('/workspace/Claude Desktop/work/batches', exist_ok=True)
keys = sorted(frontend)
N = 6
per = (len(keys) + N - 1) // N
for i in range(N):
    part = keys[i*per:(i+1)*per]
    if not part: continue
    json.dump({k: frontend[k] for k in part},
              open('/workspace/Claude Desktop/work/batches/batch-%d.json' % (i+1), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('batch-%d: %d 条' % (i+1, len(part)))
json.dump(shell, open('/workspace/Claude Desktop/work/batches/batch-shell.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch-shell: %d 条' % len(shell))
