#!/usr/bin/env python3
# 分类 struct_fail 的失败原因；识别"仅缺 ICU 分支"的可自动修复情形
import json, re

REPORT = json.load(open('/workspace/Claude Desktop/work/diff-report.json', encoding='utf-8'))

ICU_RE = re.compile(r'\{([A-Za-z_][A-Za-z0-9_.-]*),\s*(plural|selectordinal|select)\s*,')

def parse_icu_blocks(s):
    """返回 [(变量名, 类型, {分支名: 内容}, 块整体文本)]；嵌套块的内容原样保留。"""
    blocks = []
    for m in ICU_RE.finditer(s):
        i = m.start()
        depth = 0; j = i
        while j < len(s):
            if s[j] == '{': depth += 1
            elif s[j] == '}':
                depth -= 1
                if depth == 0: break
            j += 1
        if depth != 0: continue
        body = s[m.end():j]  # 变量名与类型之后、匹配 } 之前
        # 解析分支: [offset:n] 之后形如 name {content} 或 =1 {content}
        branches = {}; k = 0
        body = re.sub(r'^\s*offset\s*:\s*\d+\s*', '', body)
        while k < len(body):
            bm = re.match(r'\s*(=[0-9]+|[A-Za-z][A-Za-z0-9]*)\s*\{', body[k:])
            if not bm: break
            name = bm.group(1)
            k += bm.end()
            d = 1; start = k
            while k < len(body) and d > 0:
                if body[k] == '{': d += 1
                elif body[k] == '}': d -= 1
                k += 1
            branches[name] = body[start:k-1]
        blocks.append((m.group(1), m.group(2), branches, s[i:j+1]))
    return blocks

cats = {'plural_missing_branch': [], 'tag_mismatch': [], 'token_mismatch': [], 'other_brace': [], 'no_icu': []}
for k, pair in REPORT['frontend']['struct_fail'].items():
    en, zh = pair['en'], pair['zh']
    en_tags = sorted(re.findall(r'<[^>]*>', en))
    zh_tags = sorted(re.findall(r'<[^>]*>', zh))
    if en_tags != zh_tags:
        cats['tag_mismatch'].append(k); continue
    en_b = parse_icu_blocks(en); zh_b = parse_icu_blocks(zh)
    if not en_b:
        cats['no_icu'].append(k); continue
    # 每个英文块在中文里都能找到对应块（同变量同类型），且中文块分支是英文子集（缺的分支内容可用 other 填）
    ok = len(en_b) == len(zh_b)
    if ok:
        for (ev, et, ebr, _), (zv, zt, zbr, _) in zip(en_b, zh_b):
            if ev != zv or et != zt or not set(zbr) <= set(ebr) or 'other' not in zbr:
                ok = False; break
    if ok:
        cats['plural_missing_branch'].append(k)
    elif en.count('{') != zh.count('{'):
        cats['other_brace'].append(k)
    else:
        cats['token_mismatch'].append(k)

for c, ks in cats.items():
    print('%s: %d' % (c, len(ks)))
json.dump(cats, open('/workspace/Claude Desktop/work/fail-cats.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# 样例
for c in ('tag_mismatch', 'token_mismatch', 'other_brace', 'no_icu'):
    ks = cats[c][:3]
    print('\n--- %s 样例 ---' % c)
    for k in ks:
        p = REPORT['frontend']['struct_fail'][k]
        print('EN:', repr(p['en'][:130])); print('ZH:', repr(p['zh'][:130])); print()
