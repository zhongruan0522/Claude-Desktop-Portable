# Linux（官方 APT 版）汉化说明

适用于通过 Anthropic 官方 apt 源（`downloads.claude.ai/claude-desktop/apt/stable`）安装的
Claude Desktop，安装目录 `/usr/lib/claude-desktop`。已在 **3.6556.2（amd64）** 上完整验证：
安装 → 全量校验 → 幂等重装 → 升级检测 → 恢复后与官方原版**逐字节一致**。

## 使用

```bash
sudo ./install-linux.sh            # 安装/更新汉化
sudo ./install-linux.sh check      # 查看状态
sudo ./install-linux.sh reset      # 恢复英文原版
sudo ./install-linux.sh --set-locale   # 安装并把 ~/.config/Claude/config.json 的 locale 写为 zh-CN
```

安装完成后启动 Claude，从头像/用户菜单进入“语言”，选择“简体中文”。

- **需要 sudo**：应用目录归 root 所有；脚本非 root 运行时会自动请求提权。
- **依赖 python3**（Debian/Ubuntu 桌面自带）。
- **Claude 升级后**（`apt upgrade` 会覆盖整个应用目录）：重新运行一次 install 即可。
  脚本按版本号（deb 版本或 en-US.json 哈希）检测变化，自动清理旧备份并按新版重打；
  词典与新版英文资源自动合并，新增键以英文显示，改动了原文的旧译文会自动回退英文
  （ICU 结构安全检查），不会出现变量丢失或标签损坏。

## 与 Windows 版的对应关系

| Windows（install.cmd） | Linux（install-linux.sh） | 说明 |
| --- | --- | --- |
| `app\resources\` | `/usr/lib/claude-desktop/resources/` | 同构布局 |
| `_repair-backup\` | `/usr/lib/claude-desktop/.zh-CN-backup/` | 放在 resources 之外，避免被应用的语言枚举误读 |
| 8 个版本锁定 JS 覆盖文件 | 按内容匹配的规则集 | Linux 不用预生成 JS：白名单/名称映射/persona/硬编码规则均按内容命中，版本更迭时自动重新匹配 |
| app.asar locale 映射补丁 | 同款补丁 | Linux Electron 不校验 asar 签名；重建后全条目 SHA-256 完整性自检通过 |
| AppX 清单注册 zh-CN | 无需 | Linux 版按目录 + `[a-z]{2}-[A-Z]{2}` 正则枚举语言，`zh-CN.json` 直接被识别 |

## 覆盖率（Linux 3.6556.2，2026-10-25 全量同步）

| 层 | 键数 | 已翻译 | 说明 |
| --- | ---: | ---: | --- |
| 前端主词典 | 37,201 | 36,805（98.9%，等效 100%） | 安装器口径 0 键回退；其余 396 键为专名/OAuth scope/格式串（Google Play、CI、{kb}KB 等），按原样保留英文 |
| 前端覆盖（overrides） | 336 | 336 | |
| 动态文案 | 49 | 49 | |
| 桌面壳（菜单/弹窗/托盘） | 872 | 864（99.1%，等效 100%） | 其余 8 键为 USB、{pct}%、Claude、Pro 等专名/格式串，保留英文 |

2026-10-25 对照 3.6556.2 解包资源全量同步：新译 1,079 条长帮助文本/内置提示词模板；
修复 851 条结构不匹配（808 条为旧译缺失 ICU plural `one`/`=1` 分支，程序化补齐；
43 条英文原文变化重译）；桌面壳同步 36 条。全部通过 ICU 变量/分支/富文本标签结构校验，
干跑安装器验证 0 键回退。

术语沿用 Windows 包：
作品（Artifacts）、技能（Skills）、思考强度（Effort）、工作树（worktree）、运行器（runner）、
会话栏（Session Rail）、例行程序（routine）、计划任务（scheduled task）、快速输入（Quick Entry）、
远程控制（Remote Control）等；保留 Claude、Cowork、Claude Code、Inventory、P/S 等专名与配置值。

## 已知限制

- 订阅账号登录时，主界面在线加载 claude.ai 网页，本地语言包与 JS 补丁不覆盖该部分；
  第三方 API/中转模式走本地 ion-dist 前端，汉化完整生效（与 Windows 版一致）。
- 恢复（reset）只还原本脚本改动过的文件；`apt remove claude-desktop` 卸载不需要先 reset。
- 在线页面的 DOM 注入翻译（javaht 的 app.asar 深度改法）未移植，保持与 Windows 包相同的
  设计取向。

## 文件

- `install-linux.sh` — 主脚本（bash 编排：提权、环境检查、停进程、调用助手）
- `install-linux.py` — Python 助手（词典合并、JS/asar 补丁、备份与还原、locale 写入），
  由主脚本调用，也可单独运行：`ZH_RESOURCES=… ZH_BACKUP=… ZH_LANG=… python3 install-linux.py check`
- `language/zh-CN/linux/dictionary.json` — 前端词典（37,201 键全量映射的基础词典）
- `language/zh-CN/linux/desktop-shell-dictionary.json` — 桌面壳词典
- `language/zh-CN/linux/overrides.json` — 覆盖文案
- `language/zh-CN/dynamic/zh-CN.json` — 动态文案（Windows/Linux 通用）
- `language/zh-CN/hardcoded.json`、`frontend-hardcoded.json`、`assets-manifest.json` — JS 规则
  （与 Windows 安装器共用，安装时按当前版本内容重新匹配）
