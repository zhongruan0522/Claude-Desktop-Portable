#!/usr/bin/env python3
# Claude Desktop 汉化助手（由 install-linux.sh 调用；也可单独运行调试）
# 用法: ZH_RESOURCES=... ZH_BACKUP=... ZH_LANG=... python3 install-linux.py install|reset|check
#      python3 install-linux.py set-locale <config.json 路径>   # 以目标用户身份运行
import json, os, re, sys, hashlib, struct, shutil, subprocess

RESOURCES = os.environ.get('ZH_RESOURCES', '')
BACKUP = os.environ.get('ZH_BACKUP', '')
LANG = os.environ.get('ZH_LANG', '')
MODE = sys.argv[1] if len(sys.argv) > 1 else ''

def p(msg): print(msg, flush=True)

def load(path):
    with open(path, encoding='utf-8') as f: return json.load(f)

def detect_version():
    try:
        r = subprocess.run(['dpkg-query', '-W', '-f=${Version}', 'claude-desktop'],
                           capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip():
            return 'deb:' + r.stdout.strip()
    except Exception:
        pass
    h = hashlib.sha256(open(os.path.join(RESOURCES, 'ion-dist/i18n/en-US.json'), 'rb').read()).hexdigest()
    return 'hash:' + h[:16]

MANIFEST_PATH = os.path.join(BACKUP, 'manifest.json')
VERSION_PATH = os.path.join(BACKUP, '.version')

def read_state():
    if os.path.exists(MANIFEST_PATH):
        try: return load(MANIFEST_PATH)
        except Exception: pass
    return {'backups': [], 'deployed': []}

def backup_file(state, rel):
    """备份 resources 下相对路径 rel 的文件（仅首次，且不备份本脚本部署的文件）。"""
    src = os.path.join(RESOURCES, rel)
    dst = os.path.join(BACKUP, rel)
    if not os.path.isfile(src): return
    if rel in state['backups'] or rel in state['deployed']: return
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)
    state['backups'].append(rel)

def mark_deployed(state, rel):
    if rel not in state['deployed']:
        state['deployed'].append(rel)

def save_state(state):
    os.makedirs(BACKUP, exist_ok=True)
    with open(MANIFEST_PATH, 'w', encoding='utf-8') as f:
        json.dump({'backups': state['backups'], 'deployed': state['deployed']},
                  f, ensure_ascii=False, indent=1)

def strip_icu(value):
    s = str(value)
    res = ''; i = 0
    while i < len(s):
        if s[i] == '{':
            depth = 0; j = i
            while j < len(s):
                if s[j] == '{': depth += 1
                elif s[j] == '}':
                    depth -= 1
                    if depth == 0: break
                j += 1
            if j < len(s) and re.match(r'^[A-Za-z_][A-Za-z0-9_.-]*,\s*(plural|selectordinal|select)\s*,', s[i+1:j]):
                res += '{__ICU__}'; i = j + 1; continue
        res += s[i]; i += 1
    return res

def _tokens(value):
    c = {}; st = strip_icu(value)
    for t in re.findall(r'<[^>]*>|\{[A-Za-z_][A-Za-z0-9_.-]*\}', st): c[t] = c.get(t, 0) + 1
    return c

def struct_ok(en, zh):
    """译文与英文原文的 ICU 变量/富文本标签/花括号结构一致才可部署。"""
    a, b = str(en), str(zh)
    if a.count('{') != b.count('{') or a.count('}') != b.count('}'): return False
    if sorted(re.findall(r'<[^>]*>', a)) != sorted(re.findall(r'<[^>]*>', b)): return False
    if _tokens(a) != _tokens(b): return False
    return True

def merge_dict(en_map, zh_map):
    """返回 (合并结果, 已译键数, 因结构不匹配回退英文的键数)。"""
    out = {}; translated = 0; fell_back = 0
    for k, en in en_map.items():
        zh = zh_map.get(k)
        if zh is not None and zh != en and struct_ok(en, zh):
            out[k] = zh; translated += 1
        else:
            if zh is not None and zh != en: fell_back += 1
            out[k] = en
    return out, translated, fell_back

def write_json_atomic(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.zh-tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)

# ---------- 版本无关 locale 规则（按内容匹配；与 Windows 安装器同源） ----------
LOCALE_RULES = [
    ('["en-US","de-DE","fr-FR","ko-KR', '["en-US","zh-CN","de-DE","fr-FR","ko-KR'),
    ('"en-US":{name:"English (United States)",localName:"English (United States)"}',
     '"zh-CN":{name:"Chinese (Simplified)",localName:"简体中文"},"en-US":{name:"English (United States)",localName:"English (United States)"}'),
    ('case"en-US":return["language","en"];', 'case"zh-CN":return["language","zh-CN"];case"en-US":return["language","en"];'),
    # Linux 版适配（压缩后的变量名随构建变化，按固定片段匹配）
    ('?"Plugins":"Customize"', '?"Plugins":"自定义"'),
    ('??"Local task"', '??"本地任务"'),
]

GUARD_RE = re.compile(
    r'(?<![A-Za-z0-9_$-])(?:as|code|command|component|displayName|glyph|icon|iconName|id|key|kind|leadingIcon|locale|name|path|role|source|state|status|trailingIcon|type|value|variant)\s*[:=]\s*$')

def patch_js_assets(state):
    assets = os.path.join(RESOURCES, 'ion-dist/assets/v1')
    if not os.path.isdir(assets):
        p('· 未找到前端资源目录，跳过 JS 规则'); return
    exact_rules = list(LOCALE_RULES)
    for rel in ('assets-manifest.json', 'hardcoded.json'):
        try:
            rules = load(os.path.join(LANG, rel))
            if rel == 'assets-manifest.json':
                rules = rules.get('patches', [])
            for r in rules:
                b, a = r.get('before', ''), r.get('after', '')
                if b and a and b != a: exact_rules.append((b, a))
        except FileNotFoundError:
            pass
    plain_map = {}
    try:
        for s, t in load(os.path.join(LANG, 'frontend-hardcoded.json')):
            if not s or s == t: continue
            if re.search(r'["\\=;{}\r\n`]', s) or re.search(r'["\\{}\r\n`]', t): continue
            plain_map[s] = t
    except FileNotFoundError:
        pass

    quote_patterns = []
    for q in ('"', "'", '`'):
        qq = re.escape(q)
        quote_patterns.append((q, re.compile(qq + r'((?:\\.|[^' + qq + r'\\])*)' + qq)))

    names = os.listdir(assets)
    files = sorted(f for f in names if f.endswith('.js'))
    zst = [f for f in names if f.endswith('.js.zst')]
    if zst:
        p('· 注意：发现 %d 个 .js.zst 文件，其中内容未打补丁' % len(zst))

    patched_files = 0; exact_hits = 0; plain_hits = 0
    for name in files:
        path = os.path.join(assets, name)
        with open(path, encoding='utf-8') as f: text = f.read()
        updated = text
        for before, after in exact_rules:
            if before in updated and after not in updated:
                exact_hits += updated.count(before)
                updated = updated.replace(before, after)
        if plain_map:
            for q, pat in quote_patterns:
                hits = [0]
                def sub(m, _q=q, _hits=hits, _cur=updated):
                    v = m.group(1)
                    if v not in plain_map: return m.group(0)
                    prefix = _cur[max(0, m.start() - 96):m.start()]
                    if GUARD_RE.search(prefix): return m.group(0)
                    _hits[0] += 1
                    return _q + plain_map[v] + _q
                updated = pat.sub(sub, updated)
                plain_hits += hits[0]
        if updated == text: continue
        rel = 'ion-dist/assets/v1/' + name
        backup_file(state, rel)
        with open(path, 'w', encoding='utf-8') as f: f.write(updated)
        patched_files += 1
    p('· JS 规则：修改 %d 个文件（精确规则 %d 处，文字规则 %d 处）' % (patched_files, exact_hits, plain_hits))

def patch_asar(state):
    asar = os.path.join(RESOURCES, 'app.asar')
    data = open(asar, 'rb').read()
    json_len = int.from_bytes(data[12:16], 'little')
    header = json.loads(data[16:16 + json_len].decode('utf-8'))
    # 数据区起点 = 8 + @4（头部按 4 字节对齐，JSON 后含 NUL 与填充）
    data_start = 8 + int.from_bytes(data[4:8], 'little')
    if b'id:"id-ID",zh:"zh-CN"}' in data:
        p('· app.asar 桌面语言映射：已打过补丁'); return
    entries = []
    def walk(node):
        if isinstance(node, dict) and 'files' in node:
            for c in node['files'].values(): walk(c)
            return
        if isinstance(node, dict) and 'size' in node and 'offset' in node:
            entries.append((node, int(node['offset']), int(node['size'])))
    walk(header)
    target = None; occurrences = 0
    for node, off, size in entries:
        blob = data[data_start + off: data_start + off + size]
        occurrences += blob.count(b'id:"id-ID"}')
        if b'id:"id-ID"}' in blob and target is None:
            target = (node, blob)
    if target is None:
        p('· app.asar 中未找到 locale 映射（版本结构可能已变），已跳过；语言仍可从菜单选择'); return
    if occurrences != 1:
        p('· app.asar 中 locale 映射出现 %d 次（预期 1 次），为保证安全已跳过' % occurrences); return
    node, blob = target
    patched = blob.replace(b'id:"id-ID"}', b'id:"id-ID",zh:"zh-CN"}')

    out = bytearray()
    seen = {}
    for n, off, size in entries:
        if n is node:
            n['size'] = len(patched)
            n['offset'] = str(len(out))
            if isinstance(n.get('integrity'), dict):
                integ = n['integrity']
                bs = int(integ.get('blockSize', 4194304))
                integ['hash'] = hashlib.sha256(patched).hexdigest()
                integ['blocks'] = [hashlib.sha256(patched[i:i + bs]).hexdigest()
                                   for i in range(0, len(patched), bs)]
            out += patched
            continue
        key = (off, size)
        if key in seen:
            n['offset'] = str(seen[key]); continue
        n['offset'] = str(len(out))
        seen[key] = len(out)
        out += data[data_start + off: data_start + off + size]
    hb = json.dumps(header, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    # 复刻官方格式：[4][@4][@8][hb] json NUL 填充(4 字节对齐) 数据
    pad = (-(len(hb) + 5)) % 4
    size8 = len(hb) + 5 + pad
    new = struct.pack('<4I', 4, size8 + 4, size8, len(hb)) + hb + b'\x00' + b'\x00' * pad + out
    new_data_start = 8 + size8 + 4

    # 自检：重新解析并校验全部条目的 SHA-256 完整性
    jlen = int.from_bytes(new[12:16], 'little')
    hdr2 = json.loads(new[16:16 + jlen].decode('utf-8'))
    hits = [0]; total = [0]; hash_bad = [0]
    def walk2(n):
        if isinstance(n, dict) and 'files' in n:
            for c in n['files'].values(): walk2(c)
        elif isinstance(n, dict) and 'offset' in n:
            total[0] += 1
            start = new_data_start + int(n['offset'])
            blob = new[start:start + int(n['size'])]
            if b'id:"id-ID",zh:"zh-CN"}' in blob: hits[0] += 1
            if isinstance(n.get('integrity'), dict) and n['integrity'].get('hash'):
                if hashlib.sha256(blob).hexdigest() != n['integrity']['hash']:
                    hash_bad[0] += 1
    walk2(hdr2)
    if total[0] != len(entries) or hits[0] != 1 or hash_bad[0]:
        raise RuntimeError('asar 重建自检失败（条目 %d/%d，命中 %d，hash 错误 %d）'
                           % (total[0], len(entries), hits[0], hash_bad[0]))
    backup_file(state, 'app.asar')
    tmp = asar + '.zh-tmp'
    with open(tmp, 'wb') as f: f.write(new)
    os.replace(tmp, asar)
    p('· app.asar 桌面语言映射：已打补丁（zh → zh-CN）')

def do_install():
    version = detect_version()
    os.makedirs(BACKUP, exist_ok=True)
    state = read_state()
    old_version = ''
    if os.path.exists(VERSION_PATH):
        with open(VERSION_PATH, encoding='utf-8') as f: old_version = f.read().strip()
    if old_version and old_version != version:
        p('· 检测到 Claude 已更新（%s → %s）：清除旧备份，按当前版本重新打补丁' % (old_version, version))
        shutil.rmtree(BACKUP, ignore_errors=True)
        os.makedirs(BACKUP, exist_ok=True)
        state = {'backups': [], 'deployed': []}
    if old_version != version:
        with open(VERSION_PATH, 'w', encoding='utf-8') as f: f.write(version)

    # 1) 四层中文资源（与当前版本英文合并，缺译键回退英文）
    fe_en = load(os.path.join(RESOURCES, 'ion-dist/i18n/en-US.json'))
    fe_dict = load(os.path.join(LANG, 'linux/dictionary.json'))
    fe_out, translated, fe_fallback = merge_dict(fe_en, fe_dict)
    backup_file(state, 'ion-dist/i18n/zh-CN.json')
    write_json_atomic(os.path.join(RESOURCES, 'ion-dist/i18n/zh-CN.json'), fe_out)
    mark_deployed(state, 'ion-dist/i18n/zh-CN.json')
    save_state(state)

    ov = {k: v for k, v in load(os.path.join(LANG, 'linux/overrides.json')).items() if k in fe_en}
    ov_path = os.path.join(RESOURCES, 'ion-dist/i18n/zh-CN.overrides.json')
    if ov:
        write_json_atomic(ov_path, ov)
        mark_deployed(state, 'ion-dist/i18n/zh-CN.overrides.json')
    elif os.path.exists(ov_path):
        os.remove(ov_path)

    dyn = load(os.path.join(LANG, 'dynamic/zh-CN.json'))
    dyn_en_path = os.path.join(RESOURCES, 'ion-dist/i18n/dynamic/en-US.json')
    if os.path.exists(dyn_en_path):
        dyn_en = load(dyn_en_path)
        dyn = {k: v for k, v in dyn.items() if k in dyn_en}
    write_json_atomic(os.path.join(RESOURCES, 'ion-dist/i18n/dynamic/zh-CN.json'), dyn)
    mark_deployed(state, 'ion-dist/i18n/dynamic/zh-CN.json')

    sh_en = load(os.path.join(RESOURCES, 'en-US.json'))
    sh_dict = load(os.path.join(LANG, 'linux/desktop-shell-dictionary.json'))
    sh_out, sh_translated, sh_fallback = merge_dict(sh_en, sh_dict)
    backup_file(state, 'zh-CN.json')
    write_json_atomic(os.path.join(RESOURCES, 'zh-CN.json'), sh_out)
    mark_deployed(state, 'zh-CN.json')
    save_state(state)

    p('· 前端词典：%d/%d 键已翻译（%d 键因英文原文变化暂回退英文）' % (translated, len(fe_en), fe_fallback))
    p('· 桌面壳词典：%d/%d 键已翻译（%d 键回退英文）' % (sh_translated, len(sh_en), sh_fallback))

    # 2) 前端 JS 规则（逐文件备份，阶段结束保存状态）
    patch_js_assets(state)
    save_state(state)

    # 3) app.asar 桌面语言映射
    try:
        patch_asar(state)
    except Exception as e:
        p('· app.asar 补丁出错（%s），已跳过，不影响其余汉化' % e)

    save_state(state)
    p('')
    p('✔ 汉化完成。启动 Claude，从头像/用户菜单进入“语言”，选择“简体中文”。')

def do_reset():
    state = read_state()
    if not state['backups'] and not state['deployed']:
        p('· 没有可恢复的内容（尚未安装过汉化）'); return
    for rel in state['backups']:
        src = os.path.join(BACKUP, rel)
        dst = os.path.join(RESOURCES, rel)
        if os.path.isfile(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            p('· 已恢复 %s' % rel)
    for rel in state['deployed']:
        if rel in state['backups']: continue
        dst = os.path.join(RESOURCES, rel)
        if os.path.isfile(dst):
            os.remove(dst)
            p('· 已移除 %s' % rel)
    for f in (MANIFEST_PATH, VERSION_PATH):
        if os.path.exists(f): os.remove(f)
    shutil.rmtree(BACKUP, ignore_errors=True)
    p('✔ 已恢复英文原版。')

def do_check():
    version = detect_version()
    p('· 资源目录: %s' % RESOURCES)
    p('· 当前版本: %s' % version)
    fe = os.path.join(RESOURCES, 'ion-dist/i18n/zh-CN.json')
    if os.path.exists(fe):
        p('· 前端 zh-CN.json: 已部署（%d 键）' % len(load(fe)))
    else:
        p('· 前端 zh-CN.json: 未部署')
    sh = os.path.join(RESOURCES, 'zh-CN.json')
    if os.path.exists(sh):
        p('· 桌面壳 zh-CN.json: 已部署（%d 键）' % len(load(sh)))
    else:
        p('· 桌面壳 zh-CN.json: 未部署')
    whitelist = False
    assets = os.path.join(RESOURCES, 'ion-dist/assets/v1')
    if os.path.isdir(assets):
        for name in os.listdir(assets):
            if not name.endswith('.js'): continue
            try:
                with open(os.path.join(assets, name), encoding='utf-8') as f: t = f.read()
            except Exception: continue
            if '["en-US","zh-CN","de-DE"' in t:
                whitelist = True; break
    p('· 前端语言白名单: %s' % ('已加入 zh-CN' if whitelist else '未打补丁'))
    with open(os.path.join(RESOURCES, 'app.asar'), 'rb') as f: blob = f.read()
    p('· app.asar 语言映射: %s' % ('已打补丁' if b'id:"id-ID",zh:"zh-CN"}' in blob else '未打补丁'))
    if os.path.exists(VERSION_PATH):
        with open(VERSION_PATH, encoding='utf-8') as f: v = f.read().strip()
        p('· 补丁记录版本: %s%s' % (v, '（与当前一致）' if v == version else '（与当前不同，建议重跑 install）'))

def set_locale(path):
    """把用户 config.json 的 locale 写为 zh-CN（保留其余配置项）。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cfg = {}
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f: cfg = json.load(f)
        except Exception:
            cfg = {}
    cfg['locale'] = 'zh-CN'
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

if MODE in ('install', 'reset', 'check') and not (RESOURCES and BACKUP and LANG):
    raise SystemExit('缺少环境变量 ZH_RESOURCES / ZH_BACKUP / ZH_LANG（正常使用请运行 install-linux.sh）')
if MODE == 'install': do_install()
elif MODE == 'reset': do_reset()
elif MODE == 'check': do_check()
elif MODE == 'set-locale':
    if len(sys.argv) < 3: raise SystemExit('set-locale 需要 config.json 路径参数')
    set_locale(sys.argv[2])
else: raise SystemExit('未知模式: ' + MODE)
